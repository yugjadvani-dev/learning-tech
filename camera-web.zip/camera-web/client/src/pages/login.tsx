import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Link } from "lucide-react"

export function Login() {
  return (
    <div className="grid w-full min-h-[600px] lg:grid-cols-2">
      <div className="relative hidden lg:block">
        <img
          src="/57.jpeg"
          alt="Camera"
          className="h-full w-full object-cover"
          width="800"
          height="600"
          style={{ aspectRatio: "800/600", objectFit: "cover" }}
        />
        {/* <div className="absolute inset-0 bg-gradient-to-r from-background to-transparent" /> */}
      </div>
      <div className="flex items-center justify-center p-6 lg:p-12">
        <div className="mx-auto w-full max-w-md space-y-6">
          <div className="space-y-2 text-center">
            <h1 className="text-3xl font-bold">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to your account to continue</p>
          </div>
          <form className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="m@example.com" required />
            </div>
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link
                  to="#"
                  className="text-sm font-medium underline underline-offset-4 hover:text-primary"
                  
                >
                  Forgot password?
                </Link>
              </div>
              <Input id="password" type="password" required />
            </div>
            <Button type="submit" className="w-full">
              Sign In
            </Button>
          </form>
          <p className="text-center text-sm text-muted-foreground">
            Don&apos;t have an account?{" "}
            <Link to="#" className="font-medium underline underline-offset-4 hover:text-primary" >
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
